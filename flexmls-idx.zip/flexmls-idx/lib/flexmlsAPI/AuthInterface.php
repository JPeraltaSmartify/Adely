<?php

interface flexmlsAPI_AuthInterface {

}
