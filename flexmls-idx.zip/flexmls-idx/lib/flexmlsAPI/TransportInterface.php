<?php

interface flexmlsAPI_TransportInterface {

  function make_request($req = array());

}
