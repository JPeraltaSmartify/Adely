<?php

class flexmlsAPI_CoreTransport {


  function __construct() {
    
  }
  
  

}
