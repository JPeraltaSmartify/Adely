<?php

class FlexMLS_Settings {

	public static function admin_menu_cb_main(){
		?>
			<div class="wrap">
				<h1><?php echo get_admin_page_title(); ?></h1>
			</div>
		<?php
	}

}