<?php

class flexmlsConnectPageMyAccount {

	function pre_tasks($tag) {

		
	}


	function generate_page() {
		global $fmc_api;
		
		
		
		ob_start();
		
		
		
		
		
		
		
		
		echo "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
		
		echo "<br><br><br><br>\n\n";

		$content = ob_get_contents();
		ob_end_clean();

		return $content;
		
	}


}
