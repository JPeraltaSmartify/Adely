<?php

defined( 'ABSPATH' ) or die( 'This plugin requires WordPress' );

echo '<p>Now you&#8217;re just playing around.</p>';