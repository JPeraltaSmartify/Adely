<div class="features-outer">

	<div class="image">
		<img src="<?php echo plugins_url( 'assets/images/features-lg-img.png', dirname( __FILE__ ) ); ?>" alt="Feature">
	</div>

	<ul>
		<li>Lead Capture & Portals</li>
		<li>Search Widgets</li>
		<li>Market Stats Widgets</li>
		<li>Slideshow Assortment</li>
		<li>Unlimited Saved Searches</li>
		<li>Large Property Photos</li>
		<li>Hotsheet Pages</li>
		<li>Full Color Maps</li>
		<li>Modern User Interface</li>
	</ul>

</div>