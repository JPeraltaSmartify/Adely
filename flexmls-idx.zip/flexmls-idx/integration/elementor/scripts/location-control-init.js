(function($){
    $(document).ready(function(){
        var init = new AdminLocationSearch($('.elementor-control-field-location'));
    })
})(jQuery)