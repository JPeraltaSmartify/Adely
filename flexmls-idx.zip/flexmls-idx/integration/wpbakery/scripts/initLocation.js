
(function($){
    $(document).ready(function(){
        var init = new AdminLocationSearch($('.vc_edit_form_elements'));
    })
})(jQuery)
